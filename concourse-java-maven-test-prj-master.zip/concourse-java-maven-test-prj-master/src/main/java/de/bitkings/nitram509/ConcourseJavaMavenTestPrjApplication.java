package de.bitkings.nitram509;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConcourseJavaMavenTestPrjApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConcourseJavaMavenTestPrjApplication.class, args);
    }
}
